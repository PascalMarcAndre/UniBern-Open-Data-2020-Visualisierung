# UniBern - Open Data 2020

### Schweizer Tarifverbünde - Analyse von Kurzstrecken

Die aktuellste Version unserer Visualisierung kann unter folgendem Link angeschaut werden:  
[Live Version der Visualisierung](https://pascalmarcandre.github.io/UniBern-Open-Data-2020-Visualisierung/)